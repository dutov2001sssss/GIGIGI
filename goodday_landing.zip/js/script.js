
// Smooth internal links
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{
    const href = a.getAttribute('href');
    if(href.length>1){
      e.preventDefault();
      document.querySelector(href).scrollIntoView({behavior:'smooth'});
    }
  });
});

// Services interactivity
const services = document.querySelectorAll('.service');
services.forEach(svc=>{
  svc.addEventListener('keydown', (e)=>{
    if(e.key === 'Enter' || e.key === ' '){
      e.preventDefault(); svc.classList.toggle('active');
    }
  });
  svc.addEventListener('click', ()=>{
    services.forEach(x=>{ if(x!==svc) x.classList.remove('active') });
    svc.classList.toggle('active');
  });
});
document.addEventListener('click', (e)=>{
  if(!e.target.closest('.service')){
    services.forEach(s=>s.classList.remove('active'));
  }
});

// Phone mask (simple)
const phoneInput = document.getElementById('guestPhone');
if(phoneInput){
  phoneInput.addEventListener('input', (e)=>{
    let v = e.target.value.replace(/[^0-9+]/g,'');
    if(!v.startsWith('+')) v = '+7'+v.replace(/^7/,'');
    v = '+' + v.replace(/\D/g,'').slice(0,11);
    const m = v.replace(/\D/g,'').slice(1);
    let formatted = '+7';
    if(m.length>1) formatted = '+7 (' + (m.slice(1,4) || '');
    if(m.length>=4) formatted += ') ' + (m.slice(4,7) || '');
    if(m.length>=7) formatted += '-' + (m.slice(7,9) || '');
    if(m.length>=9) formatted += '-' + (m.slice(9,11) || '');
    e.target.value = formatted;
  });
}

// Booking form handler
function handleBooking(e){
  e.preventDefault();
  const form = e.target;
  const name = form.guestName.value.trim();
  const phone = form.guestPhone.value.trim();
  const hall = form.hallSelect.value;
  if(!name || !phone || !hall || !form.datetime.value){
    alert('Пожалуйста, заполните все поля формы.');
    return false;
  }
  alert(`Спасибо, ${name}! Ваша заявка на бронь '${hall}' принята. Мы свяжемся с вами по номеру ${phone} в ближайшее время для подтверждения.`);
  form.reset();
  return false;
}
window.handleBooking = handleBooking;

// Helper to scroll to services
function scrollToServices(hallName){
  document.querySelector('#services').scrollIntoView({behavior:'smooth'});
}
window.scrollToServices = scrollToServices;
